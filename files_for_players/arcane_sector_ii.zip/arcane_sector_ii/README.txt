The game was tested on Ubuntu 19.10 desktop. It requires SDL2 and SDL2 Image to run locally.
